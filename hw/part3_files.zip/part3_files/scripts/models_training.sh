#!/bin/bash

python3 cnn_model.py --filters 5 --kernels 3 --model_number 5
python3 cnn_model.py --filters 10 15 20 30 --kernels 3 5 7 9 --model_number 0
python3 cnn_model.py --filters 10 15 20 --kernels 3 5 7 --model_number 1
python3 cnn_model.py --filters 5 7 10 15 --kernels 3 5 5 3 --model_number 2
python3 cnn_model.py --filters 10 10 --kernels 3 3 --model_number 3
python3 cnn_model.py --filters 5 10 30 --kernels 3 6 10 --model_number 4
