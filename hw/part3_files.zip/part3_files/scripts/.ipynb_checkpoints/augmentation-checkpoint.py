import random
import nltk
# nltk.download('wordnet')
from nltk.corpus import wordnet as wn

# Получение синонимов слова из WordNet
def get_synonyms(word):
    """
    Get synonyms of a word
    """
    synonyms = set()
    
    for syn in wn.synsets(word): 
        for l in syn.lemmas(): 
            synonyms.add(l.name()) 
    
    if word in synonyms:
        synonyms.remove(word)
    
    return list(synonyms)

# Замена рандомного слова на рандомный синоним
def synonym_replacement(words, n):
    
    words = words.split()
    num_replaced = 0
    
    i_range = random.sample(range(len(words)),k=n)
    for i in i_range:
        synonyms = get_synonyms(words[i])
        if len(synonyms) >= 1:
            synonym = random.choice(list(synonyms))
            words[i] = synonym
            num_replaced += 1
            
    return ' '.join(words)

# Удаление рандомного слова
def random_deletion(words, p):

    words = words.split()
    
    # Если одно слово, то возвращаем его
    if len(words) == 1:
        return ''.join(words)

    # Удаление слова с вероятностью p
    new_words = []
    for word in words:
        r = random.uniform(0, 1)
        if r > p:
            new_words.append(word)

    # В случае удаления всех слов возвращается рандомное из оригинального текста
    if len(new_words) == 0:
        rand_int = random.randint(0, len(words)-1)
        return ''.join([words[rand_int]])

    sentence = ' '.join(new_words)
    
    return sentence


def swap_word(words):
    
    random_idx_1 = random.randint(0, len(words)-1)
    random_idx_2 = random_idx_1
    
    while random_idx_2 == random_idx_1:
        random_idx_2 = random.randint(0, len(words)-1)
    
    words[random_idx_1], words[random_idx_2] = words[random_idx_2], words[random_idx_1] 
    return words


def random_swap(words, n):
    words = words.split()
    for _ in range(n):
        words = swap_word(words)
    return ' '.join(words)


def augment_data(sentence):
    which = random.choice([1,2,3])
    if which == 1:
        sentence_edited = synonym_replacement(sentence, n=5)
    elif which == 2:
        sentence_edited = random_deletion(sentence, p=0.3)
    else:
        sentence_edited = random_swap(sentence, n=5)
    return sentence_edited








