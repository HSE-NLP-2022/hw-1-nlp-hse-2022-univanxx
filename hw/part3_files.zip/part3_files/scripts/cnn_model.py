from sklearn.metrics import f1_score
from torchtext.legacy import data
# python -m spacy download en_core_web_sm
import torch.nn as nn
import torch
import torch.optim as optim
import torch.nn.functional as F

from tqdm import tqdm
import argparse
import json

# Архитектура модели
class CNN(nn.Module):
    def __init__(self, vocab_size, embedding_dim, filters, kernels, output_dim, dropout_proba):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim)
        self.conv_layers = torch.nn.Sequential()
        # Суть: варьируем количество и фильтров и размер ядер одновременно
        for i, filter_i in enumerate(filters):
            if i == 0:
                self.conv_layers.add_module("conv_"+str(i), torch.nn.Conv2d(1, filter_i, kernel_size=(kernels[i],
                                                                                                     kernels[i]+5),
                                                                           stride=2))
            else:
                self.conv_layers.add_module("conv_"+str(i), torch.nn.Conv2d(filters[i-1], filter_i, kernel_size=(kernels[i],
                                                                                                                kernels[i]+5)))
        # Max-pooling такой, чтобы потом можно было применить линейный слой
        self.pooling = nn.AdaptiveMaxPool2d(1)
        self.fc = nn.Linear(filter_i, output_dim)
        self.dropout = nn.Dropout(dropout_proba)
        
    def forward(self, x):
        x = x.permute(1, 0)
        x = self.embedding(x).unsqueeze(1)
        x = self.conv_layers(x)
        x = self.pooling(x).squeeze()
        x = self.fc(x)
        return x

# Одна эпоха обучения и расчёт метрик и лосса
def train_func(model, iterator, optimizer, criterion):
    epoch_loss = 0
    epoch_metric = 0
    
    model.train()
    
    for batch in tqdm(iterator):
        optimizer.zero_grad()

        logits = model(batch.text).squeeze(1)
        predictions = F.softmax(logits, dim=1).argmax(dim=1).cpu()
        loss = criterion(logits.float().cpu(), batch.label.cpu().float().long())
        metric = f1_score(batch.label.cpu().float(), predictions, average='macro')
        
        loss.backward()
        optimizer.step()
        
        epoch_loss += loss
        epoch_metric += metric
        
    return epoch_loss / len(iterator), epoch_metric / len(iterator)
    

# Одна эпоха валидации и расчёт метрик и лосса
def evaluate_func(model, iterator, criterion):
    epoch_loss = 0
    epoch_metric = 0
    
    model.eval()
    
    with torch.no_grad():
        for batch in iterator:
            logits = model(batch.text).squeeze(1)
            predictions = F.softmax(logits, dim=1).argmax(dim=1).cpu()
            loss = criterion(logits.float().cpu(), batch.label.cpu().float().long())
            metric = f1_score(batch.label.cpu().float(), predictions, average='macro')

            epoch_loss += loss
            epoch_metric += metric
        
    return epoch_loss / len(iterator), epoch_metric / len(iterator)
    
    
def main(args): 
    # Подготовка данных
    TEXT = data.Field(tokenize='spacy')
    LABEL = data.LabelField()
    # Загрузка датасетов
    if args.augmented:
        train_file = 'train_augmented.csv'
    else:
        train_file = 'train_edited.csv'
    train_data, valid_data, test_data = data.TabularDataset.splits(
        path = './',
        train=train_file,
        validation='val_edited.csv',
        test='test_edited.csv',
        format='csv',
        skip_header=True,
        fields=[('text', TEXT),
            ('label', LABEL)]
    )
    # Составляем словарь (оптимальный размер подсмотрел на форумах)
    TEXT.build_vocab(train_data, max_size=25000)
    LABEL.build_vocab(train_data)
    # GPU и батчи
    device = torch.device('cuda:1' if torch.cuda.is_available() else 'cpu')
    BATCH_SIZE = 32
    train_iterator, valid_iterator, test_iterator = data.BucketIterator.splits(
        (train_data, valid_data, test_data),
        sort=False,
        batch_size=BATCH_SIZE,
        device=device)
    # Параметры обучения
    INPUT_DIM = len(TEXT.vocab)
    EMBEDDING_DIM = 100
    FILTERS = args.filters
    KERNELS = args.kernels
    OUTPUT_DIM = len(set(list(train_data.label)))
    DROPOUT_PROBA = 0.5
    # Создаём модель, оптимизатор и лосс
    model = CNN(INPUT_DIM, EMBEDDING_DIM, FILTERS, KERNELS, OUTPUT_DIM, DROPOUT_PROBA).to(device)
    optimizer = optim.Adam(model.parameters())
    criterion = nn.CrossEntropyLoss()
    # Обучение
    N_EPOCHS = 10
    valid_metric_prev, trigger = 0, 0
    for epoch in range(N_EPOCHS):
        train_loss, train_metric = train_func(model, train_iterator, optimizer, criterion)
        valid_loss, valid_metric = evaluate_func(model, valid_iterator, criterion)
        _, test_metric = evaluate_func(model, test_iterator, criterion)
        print(f'Epoch: {epoch+1:02}, Train Loss: {train_loss:.3f}, Train Macro F1: {train_metric*100:.2f}%, Val. Loss: {valid_loss:.3f}, Val. Macro F1: {valid_metric*100:.2f}%')
        # Если 3 раза ухудшилась метрика на валидации, то сворачиваем обучение
        if valid_metric < valid_metric_prev:
            trigger += 1
            if trigger == 3:
                break
        else:
            valid_metric_prev = valid_metric
    # Сохранение модели
    torch.save(model.state_dict(), './models/cnn_'+args.model_number+'.pt')
    # А также результатов в общий файл results.json
    jsonFile = open("results.json", "r") # Open the JSON file for reading
    fileData = json.load(jsonFile) # Read the JSON into the buffer
    jsonFile.close() # Close the JSON file

    fileData["kernels"].append(KERNELS)
    fileData["filters"].append(FILTERS)
    fileData["metrics_val"].append(valid_metric_prev)
    fileData["metrics_test"].append(test_metric)

    jsonFile = open("results.json", "w+")
    jsonFile.write(json.dumps(fileData))
    jsonFile.close()
    
    
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description = 'Тренировка свёрточной модели')
    parser.add_argument('--filters', nargs='+', type=int, help='Список фильтров для модели', required=True)
    parser.add_argument('--kernels', nargs='+', type=int, help='Список размеров ядер для модели', required=True)
    parser.add_argument('--model_number', type=str, help='Номер модели', required=True)
    parser.add_argument('--augmented', action='store_true', default=False,
                        help='Use augmented dataset or not')
    args = parser.parse_args()
    main(args)